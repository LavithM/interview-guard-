import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Interview.css";
import { apiFetch, getCandidateToken } from "../api";

function encodeWav(samples, sampleRate) {
  const buffer = new ArrayBuffer(44 + samples.length * 2);
  const view = new DataView(buffer);

  const writeString = (offset, value) => {
    for (let i = 0; i < value.length; i++) {
      view.setUint8(offset + i, value.charCodeAt(i));
    }
  };

  writeString(0, "RIFF");
  view.setUint32(4, 36 + samples.length * 2, true);
  writeString(8, "WAVE");
  writeString(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(36, "data");
  view.setUint32(40, samples.length * 2, true);

  let offset = 44;
  for (let i = 0; i < samples.length; i++) {
    const sample = Math.max(-1, Math.min(1, samples[i]));
    view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true);
    offset += 2;
  }

  return new Blob([view], { type: "audio/wav" });
}

function Interview() {
  const navigate = useNavigate();
  const videoRef = useRef(null);
  const cameraStreamRef = useRef(null);
  const screenStreamRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const audioContextRef = useRef(null);
  const audioProcessorRef = useRef(null);
  const audioSamplesRef = useRef([]);
  const frameTimerRef = useRef(null);
  const audioTimerRef = useRef(null);
  const windowTimerRef = useRef(null);
  const endingRef = useRef(false);
  const processingFrameRef = useRef(false);
  const processingAudioRef = useRef(false);

  const [recording, setRecording] = useState(false);
  const [error, setError] = useState("");
  const [ending, setEnding] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [aiStatus, setAiStatus] = useState("AI monitoring active");
  const [elapsed, setElapsed] = useState(0);

  const interviewId = sessionStorage.getItem("interviewguard_interview_id");
  const candidateToken = getCandidateToken();

  const sendFrame = async () => {
    if (processingFrameRef.current || !videoRef.current || !interviewId || !candidateToken) return;
    if (videoRef.current.readyState < 2) return;

    processingFrameRef.current = true;
    try {
      const canvas = document.createElement("canvas");
      canvas.width = videoRef.current.videoWidth || 640;
      canvas.height = videoRef.current.videoHeight || 480;
      const context = canvas.getContext("2d");
      context.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);

      const blob = await new Promise((resolve) =>
        canvas.toBlob(resolve, "image/jpeg", 0.7)
      );

      if (!blob) return;

      const formData = new FormData();
      formData.append("file", blob, "frame.jpg");

      await apiFetch(`/interview/${interviewId}/frame`, {
        method: "POST",
        body: formData,
      }, candidateToken);

      setAiStatus("AI monitoring active");
    } catch (err) {
      console.error("Frame upload failed", err);
      setAiStatus("AI connection retrying...");
    } finally {
      processingFrameRef.current = false;
    }
  };

  const sendAudio = async () => {
    if (processingAudioRef.current || !interviewId || !candidateToken) return;
    if (!audioSamplesRef.current.length) return;

    processingAudioRef.current = true;
    try {
      const samples = audioSamplesRef.current.splice(0);
      const sampleRate = audioContextRef.current?.sampleRate || 44100;
      const blob = encodeWav(samples, sampleRate);
      const formData = new FormData();
      formData.append("file", blob, "audio.wav");

      await apiFetch(`/interview/${interviewId}/audio`, {
        method: "POST",
        body: formData,
      }, candidateToken);
    } catch (err) {
      console.error("Audio upload failed", err);
    } finally {
      processingAudioRef.current = false;
    }
  };

  const createFeatureWindow = async () => {
    if (!interviewId || !candidateToken) return;
    try {
      await apiFetch(`/interview/${interviewId}/window`, {
        method: "POST",
      }, candidateToken);
    } catch (err) {
      console.error("Feature window failed", err);
    }
  };

  const startAudioPipeline = async (stream) => {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return;

    const context = new AudioContextClass();
    audioContextRef.current = context;

    const source = context.createMediaStreamSource(stream);
    const processor = context.createScriptProcessor(4096, 1, 1);
    const silentGain = context.createGain();
    silentGain.gain.value = 0;

    processor.onaudioprocess = (event) => {
      const input = event.inputBuffer.getChannelData(0);
      audioSamplesRef.current.push(...input);
    };

    source.connect(processor);
    processor.connect(silentGain);
    silentGain.connect(context.destination);
    audioProcessorRef.current = processor;

    if (context.state === "suspended") {
      await context.resume();
    }

    audioTimerRef.current = window.setInterval(sendAudio, 3000);
  };

  const cleanupStreams = async () => {
    if (frameTimerRef.current) window.clearInterval(frameTimerRef.current);
    if (audioTimerRef.current) window.clearInterval(audioTimerRef.current);
    if (windowTimerRef.current) window.clearInterval(windowTimerRef.current);

    frameTimerRef.current = null;
    audioTimerRef.current = null;
    windowTimerRef.current = null;

    if (audioProcessorRef.current) {
      try { audioProcessorRef.current.disconnect(); } catch {}
      audioProcessorRef.current = null;
    }

    if (audioContextRef.current) {
      try { await audioContextRef.current.close(); } catch {}
      audioContextRef.current = null;
    }

    if (cameraStreamRef.current) {
      cameraStreamRef.current.getTracks().forEach((track) => track.stop());
      cameraStreamRef.current = null;
    }

    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach((track) => track.stop());
      screenStreamRef.current = null;
    }

    window.interviewCameraStream = null;
    window.interviewScreenStream = null;
  };

  const finishInterview = async () => {
    if (!interviewId || !candidateToken) return;

    await sendAudio();

    try {
      await apiFetch(`/interview/${interviewId}/end`, {
        method: "POST",
      }, candidateToken);
    } catch (err) {
      console.error("Backend interview end failed", err);
    }

    await cleanupStreams();

    if (document.fullscreenElement) {
      try { await document.exitFullscreen(); } catch {}
    }

    setSubmitted(true);
  };

  const endInterview = async () => {
    if (endingRef.current) return;
    endingRef.current = true;
    setEnding(true);

    const recorder = mediaRecorderRef.current;
    if (recorder && recorder.state !== "inactive") {
      recorder.stop();
    } else {
      await finishInterview();
    }
  };

  const startInterview = async () => {
    try {
      setError("");
      endingRef.current = false;

      if (!interviewId || !candidateToken) {
        throw new Error("Candidate interview session is missing.");
      }

      let cameraStream = window.interviewCameraStream;
      let screenStream = window.interviewScreenStream;

      if (!cameraStream) {
        cameraStream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: true,
        });
      }

      if (!screenStream) {
        screenStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: false,
        });
      }

      cameraStreamRef.current = cameraStream;
      screenStreamRef.current = screenStream;

      if (videoRef.current) {
        videoRef.current.srcObject = cameraStream;
      }

      await startAudioPipeline(cameraStream);

      const recordingStream = new MediaStream([
        ...cameraStream.getVideoTracks(),
        ...cameraStream.getAudioTracks(),
      ]);

      let recorderOptions = {};
      if (MediaRecorder.isTypeSupported("video/webm;codecs=vp9,opus")) {
        recorderOptions = { mimeType: "video/webm;codecs=vp9,opus" };
      } else if (MediaRecorder.isTypeSupported("video/webm")) {
        recorderOptions = { mimeType: "video/webm" };
      }

      const recorder = new MediaRecorder(recordingStream, recorderOptions);
      mediaRecorderRef.current = recorder;

      recorder.onstart = () => setRecording(true);
      recorder.ondataavailable = () => {};
      recorder.onstop = async () => {
        setRecording(false);
        await finishInterview();
      };
      recorder.onerror = async () => {
        setRecording(false);
        await finishInterview();
      };

      recorder.start(1000);

      frameTimerRef.current = window.setInterval(sendFrame, 1000);
      windowTimerRef.current = window.setInterval(createFeatureWindow, 5000);
      setAiStatus("AI monitoring active");

      const screenTrack = screenStream.getVideoTracks()[0];
      if (screenTrack) {
        screenTrack.addEventListener("ended", () => {
          if (!endingRef.current) endInterview();
        });
      }
    } catch (err) {
      console.error(err);
      setError(err.message || "Camera, microphone, and screen sharing are required.");
    }
  };

  useEffect(() => {
    startInterview();

    const timer = window.setInterval(() => {
      setElapsed((value) => value + 1);
    }, 1000);

    return () => {
      window.clearInterval(timer);
    };
  }, []);

  if (submitted) {
    return (
      <div className="interview-page">
        <div className="interview-container" style={{ minHeight: "80vh", display: "flex", justifyContent: "center", alignItems: "center" }}>
          <div style={{ background: "white", padding: "50px", borderRadius: "18px", textAlign: "center", maxWidth: "550px", width: "100%", boxShadow: "0 15px 40px rgba(0,0,0,0.08)" }}>
            <div style={{ fontSize: "60px", marginBottom: "20px" }}>✅</div>
            <h1>Interview Submitted</h1>
            <p style={{ color: "#6b7280", marginTop: "15px", lineHeight: "1.6" }}>
              Your interview has been successfully submitted.
            </p>
          </div>
        </div>
      </div>
    );
  }

  const minutes = String(Math.floor(elapsed / 60)).padStart(2, "0");
  const seconds = String(elapsed % 60).padStart(2, "0");

  return (
    <div className="interview-page">
      <header className="interview-header">
        <h2>InterviewGuard</h2>
        <div className="interview-header-status">
          <span className="timer">⏱ {minutes}:{seconds}</span>
          <span>{recording ? "🔴 Recording" : "Starting..."}</span>
        </div>
      </header>

      <div className="interview-container">
        <div className="camera-box">
          {error ? (
            <div className="camera-error">
              <p>{error}</p>
              <button type="button" onClick={startInterview}>TRY AGAIN</button>
            </div>
          ) : (
            <video ref={videoRef} autoPlay muted playsInline className="camera-video" />
          )}
        </div>

        <div className="interview-status">
          <h2>Interview in Progress</h2>
          <p className="recording">{recording ? "🔴 Interview Recording Active" : "Starting recording..."}</p>
          <p>Please remain in front of the camera throughout the interview.</p>
          <p style={{ color: "#16a34a", fontWeight: 600 }}>{aiStatus}</p>
          <p style={{ fontSize: 13, color: "#9ca3af" }}>
            AI results are not shown to the candidate during the interview.
          </p>
        </div>

        <button type="button" className="end-button" onClick={endInterview} disabled={ending}>
          {ending ? "SUBMITTING INTERVIEW..." : "END INTERVIEW"}
        </button>
      </div>
    </div>
  );
}

export default Interview;
