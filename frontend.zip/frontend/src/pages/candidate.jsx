import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import "./Candidate.css";
import { apiFetch } from "../api";

function Candidate() {
  const navigate = useNavigate();
  const { invitationToken: routeToken } = useParams();
  const [email, setEmail] = useState("");
  const [token, setToken] = useState(routeToken || "");
  const [candidate, setCandidate] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (routeToken) {
      setToken(routeToken);
      sessionStorage.setItem("interviewguard_invitation_token", routeToken);
    } else {
      const saved = sessionStorage.getItem("interviewguard_invitation_token");
      if (saved) setToken(saved);
    }
  }, [routeToken]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!token) {
      setError("Please open the interview link provided by the interviewer.");
      return;
    }

    if (!email.trim()) {
      setError("Please enter your registered email.");
      return;
    }

    try {
      setLoading(true);
      const data = await apiFetch("/candidate/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          invitation_token: token,
          email: email.trim(),
        }),
      });

      sessionStorage.setItem(
        "interviewguard_candidate_token",
        data.access_token
      );
      sessionStorage.setItem(
        "interviewguard_candidate",
        JSON.stringify(data.candidate)
      );
      sessionStorage.setItem(
        "interviewguard_interview_id",
        data.candidate.interview_id
      );

      setCandidate(data.candidate);
      navigate("/verification");
    } catch (err) {
      setError(err.message || "Candidate login failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="candidate-page">
      <div className="candidate-card">
        <h1>Candidate Login</h1>
        <p>
          Enter your registered email to join the interview.
        </p>

        <form onSubmit={handleSubmit}>
          <label>Registered Email</label>
          <input
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          {!routeToken && (
            <>
              <label>Interview Link Token</label>
              <input
                type="text"
                placeholder="Paste the interview token"
                value={token}
                onChange={(e) => setToken(e.target.value.trim())}
              />
            </>
          )}

          {error && <small className="error">{error}</small>}

          <button type="submit" disabled={loading}>
            {loading ? "VERIFYING..." : "CONTINUE"}
          </button>
        </form>

        {candidate && (
          <p style={{ marginTop: 15 }}>
            Welcome, {candidate.name}.
          </p>
        )}
      </div>
    </div>
  );
}

export default Candidate;
