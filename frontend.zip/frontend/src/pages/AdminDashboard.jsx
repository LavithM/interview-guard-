import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./admin/AdminDashboard.css";
import { apiFetch, getAdminToken, wsUrl } from "../api";

function AdminDashboard() {
  const navigate = useNavigate();
  const token = getAdminToken();

  const [candidateName, setCandidateName] = useState("");
  const [candidateEmail, setCandidateEmail] = useState("");
  const [role, setRole] = useState("Software Developer");

  const [interviews, setInterviews] = useState([]);
  const [createdLink, setCreatedLink] = useState("");

  const [live, setLive] = useState({});
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  // --------------------------------------------------
  // LOAD RECENT INTERVIEWS
  // --------------------------------------------------

  const loadInterviews = async () => {
    if (!token) {
      navigate("/admin");
      return;
    }

    try {
      const data = await apiFetch(
        "/admin/interviews/recent?limit=100",
        {},
        token
      );

      setInterviews(data.interviews || []);
      setError("");
    } catch (err) {
      console.error("Failed to load interviews:", err);
      setError(err.message || "Failed to load interviews.");
    }
  };

  // --------------------------------------------------
  // LOAD INTERVIEWS EVERY 5 SECONDS
  // --------------------------------------------------

  useEffect(() => {
    loadInterviews();

    const timer = window.setInterval(() => {
      loadInterviews();
    }, 5000);

    return () => {
      window.clearInterval(timer);
    };
  }, []);

  // --------------------------------------------------
  // LIVE WEBSOCKET CONNECTIONS
  // --------------------------------------------------

  useEffect(() => {
    const activeInterviews = interviews.filter(
      (item) => item.status === "active"
    );

    const sockets = [];

    activeInterviews.forEach((item) => {
      try {
        const socket = new WebSocket(
          wsUrl(`/ws/admin/${item.interview_id}`, token)
        );

        sockets.push(socket);

        socket.onopen = () => {
          console.log(
            "Live connection opened:",
            item.interview_id
          );
        };

        socket.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);

            setLive((current) => ({
              ...current,
              [item.interview_id]: data,
            }));
          } catch (err) {
            console.error(
              "Invalid live update:",
              err
            );
          }
        };

        socket.onerror = (err) => {
          console.error(
            "WebSocket error:",
            item.interview_id,
            err
          );
        };

        socket.onclose = () => {
          console.log(
            "Live connection closed:",
            item.interview_id
          );
        };
      } catch (err) {
        console.error(
          "Could not create WebSocket:",
          err
        );
      }
    });

    return () => {
      sockets.forEach((socket) => {
        try {
          socket.close();
        } catch {
          // Ignore already closed sockets
        }
      });
    };
  }, [interviews, token]);

  // --------------------------------------------------
  // CREATE INTERVIEW
  // --------------------------------------------------

  const createInterview = async (e) => {
    e.preventDefault();

    setError("");
    setCreatedLink("");

    if (
      !candidateName.trim() ||
      !candidateEmail.trim() ||
      !role.trim()
    ) {
      setError(
        "Candidate name, email and role are required."
      );
      return;
    }

    try {
      setLoading(true);

      const data = await apiFetch(
        "/admin/interviews",
        {
          method: "POST",

          headers: {
            "Content-Type": "application/json",
          },

          body: JSON.stringify({
            candidate_name: candidateName.trim(),
            candidate_email: candidateEmail.trim(),
            role: role.trim(),
          }),
        },
        token
      );

      // Backend returns the link inside invitation
      const link =
        data?.invitation?.candidate_link ||
        data?.candidate_link ||
        "";

      setCreatedLink(link);

      setCandidateName("");
      setCandidateEmail("");
      setRole("Software Developer");

      await loadInterviews();
    } catch (err) {
      console.error(
        "Failed to create interview:",
        err
      );

      setError(
        err.message ||
          "Failed to create interview."
      );
    } finally {
      setLoading(false);
    }
  };

  // --------------------------------------------------
  // COPY LINK
  // --------------------------------------------------

  const copyLink = async (link) => {
    if (!link) {
      return;
    }

    try {
      await navigator.clipboard.writeText(link);

      alert("Interview link copied.");
    } catch (err) {
      console.error(
        "Could not copy link:",
        err
      );

      alert(
        "Could not copy the link. Please copy it manually."
      );
    }
  };

  // --------------------------------------------------
  // LOGOUT
  // --------------------------------------------------

  const logout = () => {
    localStorage.removeItem(
      "interviewguard_admin_token"
    );

    localStorage.removeItem(
      "interviewguard_admin_user"
    );

    navigate("/admin");
  };

  // --------------------------------------------------
  // DISPLAY STATUS
  // --------------------------------------------------

  const getStatusLabel = (status) => {
    if (status === "pending") {
      return "Invited";
    }

    if (status === "active") {
      return "Active";
    }

    if (status === "completed") {
      return "Completed";
    }

    return status || "Unknown";
  };

  const getStatusClass = (status) => {
    if (status === "pending") {
      return "status status-invited";
    }

    if (status === "active") {
      return "status status-active";
    }

    if (status === "completed") {
      return "status status-completed";
    }

    return "status";
  };

  // --------------------------------------------------
  // STATISTICS
  // --------------------------------------------------

  const stats = useMemo(
    () => ({
      total: interviews.length,

      active: interviews.filter(
        (item) => item.status === "active"
      ).length,

      completed: interviews.filter(
        (item) => item.status === "completed"
      ).length,

      invited: interviews.filter(
        (item) => item.status === "pending"
      ).length,
    }),
    [interviews]
  );

  // --------------------------------------------------
  // RENDER
  // --------------------------------------------------

  return (
    <div className="admin-dashboard">

      {/* ================================================= */}
      {/* SIDEBAR */}
      {/* ================================================= */}

      <aside className="admin-sidebar">

        <div className="dashboard-logo">
          InterviewGuard
        </div>

        <p className="sidebar-title">
          ADMIN PANEL
        </p>

        <div className="sidebar-menu">

          <button className="active">
            Dashboard
          </button>

          <button
            onClick={() =>
              document
                .querySelector(".interviews-section")
                ?.scrollIntoView({
                  behavior: "smooth",
                })
            }
          >
            Interviews
          </button>

          <button
            onClick={() =>
              document
                .querySelector(".live-section")
                ?.scrollIntoView({
                  behavior: "smooth",
                })
            }
          >
            Live Monitor
          </button>

          <button
            onClick={() =>
              document
                .querySelector(".reports-section")
                ?.scrollIntoView({
                  behavior: "smooth",
                })
            }
          >
            Reports
          </button>

        </div>

        <button
          className="logout-button"
          onClick={logout}
        >
          Logout
        </button>

      </aside>

      {/* ================================================= */}
      {/* MAIN */}
      {/* ================================================= */}

      <main className="dashboard-main">

        {/* HEADER */}

        <header className="dashboard-header">

          <div>

            <h1>
              Admin Dashboard
            </h1>

            <p>
              Create interviews and monitor
              candidates in real time.
            </p>

          </div>

          <div className="admin-profile">
            Admin
          </div>

        </header>

        {/* ================================================= */}
        {/* STATISTICS */}
        {/* ================================================= */}

        <section className="stats">

          <div className="stat-card">
            <span>
              Total Interviews
            </span>

            <strong>
              {stats.total}
            </strong>
          </div>

          <div className="stat-card">
            <span>
              Active Now
            </span>

            <strong>
              {stats.active}
            </strong>
          </div>

          <div className="stat-card">
            <span>
              Invited
            </span>

            <strong>
              {stats.invited}
            </strong>
          </div>

          <div className="stat-card">
            <span>
              Completed
            </span>

            <strong>
              {stats.completed}
            </strong>
          </div>

        </section>

        {/* ================================================= */}
        {/* CREATE INTERVIEW */}
        {/* ================================================= */}

        <section className="create-exam">

          <h2>
            Create Interview
          </h2>

          <form onSubmit={createInterview}>

            <div
              className="form-row"
              style={{
                gridTemplateColumns:
                  "1fr 1fr",
              }}
            >

              <div>

                <label>
                  Candidate Name
                </label>

                <input
                  value={candidateName}
                  onChange={(e) =>
                    setCandidateName(
                      e.target.value
                    )
                  }
                  placeholder="Candidate name"
                />

              </div>

              <div>

                <label>
                  Candidate Email
                </label>

                <input
                  type="email"
                  value={candidateEmail}
                  onChange={(e) =>
                    setCandidateEmail(
                      e.target.value
                    )
                  }
                  placeholder="candidate@example.com"
                />

              </div>

            </div>

            <div
              style={{
                marginTop: 18,
              }}
            >

              <label>
                Interview Role
              </label>

              <input
                value={role}
                onChange={(e) =>
                  setRole(e.target.value)
                }
                placeholder="Software Developer"
              />

            </div>

            {error && (
              <p
                style={{
                  color: "#dc2626",
                }}
              >
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
            >
              {loading
                ? "CREATING..."
                : "CREATE INTERVIEW LINK"}
            </button>

          </form>

          {/* CREATED LINK */}

          {createdLink && (
            <div className="generated-code">

              <p>
                Interview created successfully.
              </p>

              <span>
                Candidate Interview Link
              </span>

              <strong
                style={{
                  fontSize: 15,
                  letterSpacing: 0,
                  overflowWrap: "anywhere",
                }}
              >
                {createdLink}
              </strong>

              <button
                type="button"
                onClick={() =>
                  copyLink(createdLink)
                }
              >
                COPY LINK
              </button>

            </div>
          )}

        </section>

        {/* ================================================= */}
        {/* INTERVIEWS */}
        {/* ================================================= */}

        <section className="interviews-section exam-section">

          <div className="section-header">

            <h2>
              Interviews
            </h2>

            <span>
              {interviews.length} interview(s)
            </span>

          </div>

          {interviews.length === 0 ? (

            <div className="empty-state">

              <h3>
                No interviews created yet
              </h3>

              <p>
                Create an interview above
                to generate a candidate link.
              </p>

            </div>

          ) : (

            <div className="exam-table">

              {/* TABLE HEADER */}

              <div className="table-header interview-table-grid">

                <span>
                  Candidate
                </span>

                <span>
                  Email
                </span>

                <span>
                  Role
                </span>

                <span>
                  Interview ID
                </span>

                <span>
                  Status
                </span>

                <span>
                  Interview Link
                </span>

                <span>
                  Report
                </span>

              </div>

              {/* TABLE ROWS */}

              {interviews.map((item) => (

                <div
                  className="table-row interview-table-grid"
                  key={item.interview_id}
                >

                  <span>
                    {item.candidate_name}
                  </span>

                  <span>
                    {item.candidate_email}
                  </span>

                  <span>
                    {item.role}
                  </span>

                  <span className="code">
                    {item.interview_id}
                  </span>

                  <span
                    className={getStatusClass(
                      item.status
                    )}
                  >
                    {getStatusLabel(
                      item.status
                    )}
                  </span>

                  <span className="link-cell">

                    {item.candidate_link ? (

                      <button
                        type="button"
                        className="link-button"
                        onClick={() =>
                          copyLink(
                            item.candidate_link
                          )
                        }
                      >
                        COPY LINK
                      </button>

                    ) : (

                      <span className="no-link">
                        Not available
                      </span>

                    )}

                  </span>

                  <span>

                    <button
                      type="button"
                      onClick={() =>
                        navigate(
                          `/admin/report/${item.interview_id}`
                        )
                      }
                    >
                      VIEW
                    </button>

                  </span>

                </div>

              ))}

            </div>

          )}

        </section>

        {/* ================================================= */}
        {/* LIVE AI MONITOR */}
        {/* ================================================= */}

        <section
          className="live-section candidates-section"
        >

          <div className="section-header">

            <h2>
              Live AI Monitor
            </h2>

            <span>
              Only active interviews are shown
            </span>

          </div>

          {stats.active === 0 ? (

            <div className="empty-state">

              <h3>
                No active interview
              </h3>

              <p>
                When a candidate starts an
                interview, live AI information
                will appear here.
              </p>

            </div>

          ) : (

            interviews
              .filter(
                (item) =>
                  item.status === "active"
              )
              .map((item) => {

                const state =
                  live[item.interview_id];

                const analysis =
                  state?.latest_analysis || {};

                const fusion =
                  analysis.fusion || {};

                const objects =
                  fusion.objects || {};

                const model =
                  analysis.model_prediction ||
                  {};

                return (

                  <div
                    key={item.interview_id}
                    style={{
                      border:
                        "1px solid #e5e7eb",
                      borderRadius: 12,
                      padding: 20,
                      marginBottom: 16,
                    }}
                  >

                    <h3
                      style={{
                        marginTop: 0,
                      }}
                    >
                      {item.candidate_name}
                    </h3>

                    <p>
                      {item.role} ·{" "}
                      {item.candidate_email}
                    </p>

                    <div
                      style={{
                        display: "grid",
                        gridTemplateColumns:
                          "repeat(4, 1fr)",
                        gap: 12,
                      }}
                    >

                      <div className="stat-card">

                        <span>
                          Face
                        </span>

                        <strong>
                          {fusion.face_status ||
                            "waiting"}
                        </strong>

                      </div>

                      <div className="stat-card">

                        <span>
                          People
                        </span>

                        <strong>
                          {objects
                            .maximum_person_count ??
                            "-"}
                        </strong>

                      </div>

                      <div className="stat-card">

                        <span>
                          Phone
                        </span>

                        <strong>
                          {objects
                            .mobile_phone_detected
                            ? "Detected"
                            : "Not detected"}
                        </strong>

                      </div>

                      <div className="stat-card">

                        <span>
                          Speech
                        </span>

                        <strong>
                          {analysis.speech_detected
                            ? "Detected"
                            : "Quiet"}
                        </strong>

                      </div>

                    </div>

                    <p
                      style={{
                        marginBottom: 0,
                        marginTop: 15,
                      }}
                    >
                      AI stream:{" "}
                      {state
                        ? "Connected"
                        : "Connecting..."}{" "}
                      · Model prediction
                      available:{" "}
                      {model.prediction_available
                        ? "Yes"
                        : "No"}
                    </p>

                    <p
                      style={{
                        fontSize: 13,
                        color: "#6b7280",
                      }}
                    >
                      These are live
                      indicators/evidence
                      signals, not a final
                      cheating verdict.
                    </p>

                  </div>

                );
              })

          )}

        </section>

      </main>

    </div>
  );
}

export default AdminDashboard;