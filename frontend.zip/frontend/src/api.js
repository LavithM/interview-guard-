export const API_BASE =
  import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:8000";

export function getAdminToken() {
  return localStorage.getItem("interviewguard_admin_token");
}

export function getCandidateToken() {
  return sessionStorage.getItem("interviewguard_candidate_token");
}

export async function apiFetch(path, options = {}, token = null) {
  const headers = new Headers(options.headers || {});

  if (token) {
    headers.set("Authorization", `Bearer ${token}`);
  }

  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers,
  });

  const text = await response.text();
  let data = {};

  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { detail: text || "Request failed" };
  }

  if (!response.ok) {
    throw new Error(data.detail || `Request failed (${response.status})`);
  }

  return data;
}

export function wsUrl(path, token) {
  const base = API_BASE.replace(/^http/, "ws");
  return `${base}${path}?token=${encodeURIComponent(token)}`;
}
